﻿namespace Zad3.Interfaces.Models
{
    public interface IBaseEntity
    {
        int Id { get; set; }
        string Name { get; set; }
    }
}