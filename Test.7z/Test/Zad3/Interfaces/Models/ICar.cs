﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad3.Interfaces.Models
{
    public interface ICar
    {
        string Type { get; set; }
        string Color { get; set; }
    }
}
